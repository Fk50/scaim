This was a font i could't handle from the start, and i never liked the original look it had..at all, so i updated most of the uppercase.

Hope you like it


Contact
urban_ninja4real@hotmail.com
